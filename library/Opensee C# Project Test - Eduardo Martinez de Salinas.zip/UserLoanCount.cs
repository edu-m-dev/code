﻿namespace Library
{
    public class UserLoanCount
    {
        public User User { get; set; }
        public int LoanCount { get; set; }
    }
}